@extends('layout.main')

@section('title')
    Data Cuti
@endsection

@section('content')
    <section class="section dashboard">
        <div class="row">

            <div class="col-lg-4">
                <h1>Ini Halaman Data Cuti</h1>
            </div>

        </div>
    </section>
@endsection
