<nav class="main-header navbar navbar-expand" style="background-color: #5E72E4; border-bottom-color: #5E72E4;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link ms-3" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: black;"></i></a>
      </li>
    </ul>
</nav><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/navbar.blade.php ENDPATH**/ ?>