<?php $__env->startSection('title'); ?>
    Data Pegawai Kelola Pegawai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer"/>

<div class="p-4">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('createpegawaiopd')); ?>" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i><span> Tambah Pegawai</span></a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
            <h1 class="card-title"></h1>
            <table id="data_pegawai" class="table table-striped" style="width:100%; ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <th>Satuan Kerja</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $tb_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($pgw->NIP); ?></td>
                            <td><?php echo e($pgw->Nama_Pegawai); ?></td>
                            <td><?php echo e($pgw->dinas->Dinas); ?></td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <button type="button" class="btn btn-outline-info btn-sm"
                                        style="margin-right: 5px; border-radius:5px;" data-bs-toggle="modal"
                                        data-bs-target="#viewperiksa<?php echo e($pgw->NIP); ?>"><i class="far fa-eye"></i></button>

                                    <!-- Tambahkan margin-right di sini untuk memberikan jarak -->
                                    <a href="<?php echo e(route('editapegawaiopd', ['id' => $pgw->NIP])); ?>"
                                        class="btn btn-outline-warning btn-sm"
                                        style="margin-right: 5px; border-radius:5px;">
                                        <i class="far fa-edit"></i>
                                    </a>

                                    <form action="<?php echo e(route('deletepegawaiopd', ['id' => $pgw->NIP])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" value="Delete" class="btn btn-outline-secondary btn-sm"
                                            style="border-radius:5px;"><i class="far fa-trash-alt"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h1 class="card-title"></h1>
        </div>
    </div>
</div>
<?php $__currentLoopData = $tb_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal Diagnosa-->
    <div class="modal fade" id="viewperiksa<?php echo e($pgw->NIP); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
        tabindex="-1" aria-labelledby="viewperiksalabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="viewperiksalabel">Data Pegawai</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table cellpadding="5">
                        <tr>
                            <td><b>NIP</b></td>
                            <td>: <?php echo e($pgw->NIP); ?></td>
                        </tr>
                        <tr>
                            <td><b>Nama</b></td>
                            <td>: <?php echo e($pgw->Nama_Pegawai); ?></td>
                        </tr>
                        <tr>
                            <td><b>Tempat Lahir</b></td>
                            <td>: <?php echo e($pgw->Tempat_Lahir); ?></td>
                        </tr>
                        <tr>
                            <td><b>Tanggal Lahir</b></td>
                            <td>: <?php echo e($pgw->Tanggal_Lahir); ?></td>
                        </tr>
                        <tr>
                            <td><b>Jenis Kelamin</b></td>
                            <td>: <?php echo e($pgw->Id_Jenis_Kelamin); ?></td>
                        </tr>
                        <tr>
                            <td><b>Jabatan</b></td>
                            <td>: <?php echo e($pgw->Id_Jabatan); ?></td>
                        </tr>
                        <tr>
                            <td><b>Dinas</b></td>
                            <td>: <?php echo e($pgw->Id_Dinas); ?></td>
                        </tr>
                        <tr>
                            <td><b>Tanggal Mulai</b></td>
                            <td>: <?php echo e($pgw->Tanggal_Mulai); ?></td>
                        </tr>
                        <tr>
                            <td><b>Alamat</b></td>
                            <td>: <?php echo e($pgw->Alamat_Pegawai); ?></td>
                        </tr>
                        <tr>
                            <td><b>Golongan</b></td>
                            <td>: <?php echo e($pgw->Id_Golongan); ?></td>
                        </tr>
                        <tr>
                            <td><b>Telepon Pegawai</b></td>
                            <td>: <?php echo e($pgw->Telepon_Pegawai); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>")
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/opd/kelolapegawai.blade.php ENDPATH**/ ?>