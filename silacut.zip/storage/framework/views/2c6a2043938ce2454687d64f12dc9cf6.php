<?php $__env->startSection('title'); ?>
    Data Pegawai Edit Data Pegawai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="p-4">
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-title pt-3">
                        <h5 class="text-center">Form Edit Data Pegawai</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('updatepegawaiopd', ['id' => $tb_pegawai->NIP])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <!-- <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtid" class="form-label">NIP</label>
                                <div class="input-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['txtid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Masukkan NIP" name="NIP" id="txtid"
                                        value="<?php echo e(old('NIP', $tb_pegawai->NIP)); ?>">
                                    <?php $__errorArgs = ['txtid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div> -->

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtname" class="form-label">Nama Pegawai</label>
                                <div class="input-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['txtname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Masukkan Nama" name="Nama Pegawai" id="txtname"
                                        value="<?php echo e(old('Nama Pegawai', $tb_pegawai->Nama_Pegawai)); ?>">
                                    <?php $__errorArgs = ['txtname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtbirthplace" class="form-label">Tempat Lahir</label>
                                <div class="input-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['txtbirthplace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Tempat Lahir" name="Tempat Lahir" id="txtbirthplace"
                                        value="<?php echo e(old('Tempat Lahir', $tb_pegawai->Tempat_Lahir)); ?>">
                                    <?php $__errorArgs = ['txtbirthplace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtdateofbirth" class="form-label required-label">Tanggal Lahir</label>
                                <div class="input-group">
                                    <input type="date" class="form-control <?php $__errorArgs = ['txtdateofbirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="Tanggal Lahir" id="txtdateofbirth"
                                        value="<?php echo e(old('Tanggal Lahir', $tb_pegawai->Tanggal_Lahir)); ?>">
                                    <?php $__errorArgs = ['txtdateofbirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style="margin-bottom:15px;">
                                <label class="form-label">Jenis Kelamin</label>
                                <div class="input-group">
                                    <select class="form-select <?php $__errorArgs = ['txtgender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        aria-label="Default select example" id="txtgender" name="Id_Jenis_Kelamin">
                                        <option selected>Pilih Jenis Kelamin</option>
                                        <?php $__currentLoopData = $tb_jenis_kelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbjk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tbjk->Id_Jenis_Kelamin); ?>"
                                                <?php echo e(old('Id_Jenis_Kelamin', $tb_pegawai->Id_Jenis_Kelamin) == $tbjk->Id_Jenis_Kelamin ? 'selected' : ''); ?>>
                                                <?php echo e($tbjk->Jenis_Kelamin); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['txtgender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12" style="margin-bottom:15px;">
                                <label class="form-label">Jabatan</label>
                                <div class="input-group">
                                    <select class="form-select <?php $__errorArgs = ['txtposition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        aria-label="Default select example" name="Id_Jabatan">
                                        <option selected>Pilih Jabatan</option>
                                        <?php $__currentLoopData = $tb_jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tbj->Id_Jabatan); ?>"
                                                <?php echo e(old('Id_Jabatan', $tb_pegawai->Id_Jabatan) == $tbj->Id_Jabatan ? 'selected' : ''); ?>>
                                                <?php echo e($tbj->Jabatan); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['txtposition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </select>
                                </div>
                            </div>

                            <!-- <div class="col-md-12" style=" margin-bottom:15px;">
                                <label class="form-label">Dinas</label>
                                <div class="input-group">
                                    <select class="form-select <?php $__errorArgs = ['txtdepartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        aria-label="Default select example" name="Id_Dinas">
                                        <option selected>Pilih Dinas</option>
                                        <?php $__currentLoopData = $tb_dinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tbd->Id_Dinas); ?>"
                                                <?php echo e(old('Id_Dinas', $tb_pegawai->Id_Dinas) == $tbd->Id_Dinas ? 'selected' : ''); ?>>
                                                <?php echo e($tbd->Dinas); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['txtdepartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </select>
                                </div>
                            </div> -->

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtstartingdate" class="form-label required-label">Tanggal Mulai</label>
                                <div class="input-group">
                                    <input type="date" class="form-control" name="Tanggal_Mulai" id="txtstartingdate"
                                        value="<?php echo e(old('Tanggal_Mulai', $tb_pegawai->Tanggal_Mulai, date('Y-m-d'))); ?>">
                                    <?php $__errorArgs = ['txtstartingdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtaddress" class="form-label">Alamat</label>
                                <div class="input-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['txtaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Masukkan Alamat Pegawai" name="Alamat_Pegawai" id="txtaddress"
                                        value="<?php echo e(old('Alamat', $tb_pegawai->Alamat_Pegawai)); ?>">
                                    <?php $__errorArgs = ['txtaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtKuota" class="form-label">Kuota Cuti</label>
                                <div class="input-group">
                                    <input type="number" class="form-control <?php $__errorArgs = ['txtKuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Masukkan Banyak Cuti" name="Kuota_Cuti" id="txtKuota"
                                        value="<?php echo e(old('Kuota_Cuti', $tb_pegawai->Kuota_Cuti)); ?>">
                                    <?php $__errorArgs = ['txtKuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12" style="margin-bottom:15px;">
                                <label class="form-label">Golongan</label>
                                <div class="input-group">
                                    <select class="form-select <?php $__errorArgs = ['txtgroup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        aria-label="Default select example" name="Id_Golongan">
                                        <option selected>Pilih Golongan</option>
                                        <?php $__currentLoopData = $tb_golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tbg->Id_Golongan); ?>"
                                                <?php echo e(old('Id_Golongan', $tb_pegawai->Id_Golongan) == $tbg->Id_Golongan ? 'selected' : ''); ?>>
                                                <?php echo e($tbg->Golongan); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['txtgroup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12" style=" margin-bottom:15px;">
                                <label for="txtphone" class="form-label">Telepon Pegawai</label>
                                <div class="input-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['txtphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Masukkan Nomor Telepon" name="Telepon_Pegawai" id="txtphone"
                                        value="<?php echo e(old('Telepon_Pegawai', $tb_pegawai->Telepon_Pegawai)); ?>">
                                    <?php $__errorArgs = ['txtphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <a href="javascript:history.back()" class="btn btn-outline-secondary"
                                        style="margin-left: auto;"><i class="fa-solid fa-backward"></i><span>
                                            Kembali</span></a>
                                    <button type="submit" name="submit" value="Save"
                                        class="btn btn-custom">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/opd/kelolapegawai/edit.blade.php ENDPATH**/ ?>