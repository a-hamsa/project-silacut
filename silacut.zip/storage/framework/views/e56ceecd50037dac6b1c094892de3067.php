<?php $__env->startSection('title'); ?>
    Kelola OPD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="p-4">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-end">
                <a href="kelolaopd/create" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i><span> Tambah OPD</span></a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md">
            <h1 class="card-title"></h1>
            <table id="kelolapegawaibkd" class="table table-striped" style="width:100%; ">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama OPD</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $tb_dinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($dns->Dinas == "BKD" || $dns->Dinas == "-"): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration -2); ?></th>
                            <td><?php echo e($dns->Dinas); ?></td>
                            
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    

                                    <!-- Tambahkan margin-right di sini untuk memberikan jarak -->
                                    <a href="kelolaopd/<?php echo e($dns->Id_Dinas); ?>/edit"
                                        class="btn btn-outline-warning btn-sm"
                                        style="margin-right: 5px; border-radius:5px;">
                                        <i class="far fa-edit"></i>
                                    </a>

                                    <form action="kelolaopd/<?php echo e($dns->Id_Dinas); ?>" method="POST" id="deleteFormKelolaOpd">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-secondary btn-sm delete" data-nama="<?php echo e($dns->Dinas); ?>"
                                            style="border-radius:5px;"><i class="far fa-trash-alt"></i></button>
                                    </form>
                                    
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h1 class="card-title"></h1>
        </div>
    </div>
</div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/bkd/kelolaopd.blade.php ENDPATH**/ ?>