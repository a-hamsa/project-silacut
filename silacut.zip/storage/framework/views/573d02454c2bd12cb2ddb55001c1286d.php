<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.0.1
    </div>
    <strong>Copyright © 2024 <a href="">Morowali</a>.</strong> All rights reserved.
</footer><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/footer.blade.php ENDPATH**/ ?>