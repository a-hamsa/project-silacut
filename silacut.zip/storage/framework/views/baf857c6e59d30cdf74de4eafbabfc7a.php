<aside class="main-sidebar sidebar-white-primary elevation-4 d-flex flex-column h-100 pb-4">
<?php if($user->Id_Role == 1): ?>
  <a href="<?php echo e(route('dashboardbkd')); ?>" class="brand-link text-decoration-none">
    <img src="<?php echo e(asset('assets/img/silacut.png')); ?>" alt="Logo" class="img-fluid">
  </a>
<?php elseif($user->Id_Role == 2): ?>
  <a href="<?php echo e(route('dashboardopd')); ?>" class="brand-link text-decoration-none">
    <img src="<?php echo e(asset('assets/img/silacut.png')); ?>" alt="Logo" class="img-fluid">
  </a>
<?php endif; ?>
  <div class="sidebar text-white d-flex flex-column h-100">
    <nav class="mt-3">
      <ul class="nav nav-pills nav-sidebar" style="font-size: 18px;" data-widget="treeview" role="menu" data-accordion="false">
        <?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </ul>
      <hr>
    </nav>
    <!-- Logout link outside the nav element -->
    <div class="justify-content-end mt-auto px-1">
      <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button class="btn btn-secondary w-100 text-start" type="submit">
          <i class="fa-solid fa-arrow-right-from-bracket"></i>
          Logout
        </button>
      </form>
    </div>
  </div>
</aside>
<?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>