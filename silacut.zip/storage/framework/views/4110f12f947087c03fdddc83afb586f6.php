<?php $__env->startSection('content'); ?>
<div class="row m-0">
    <div class="col-4 d-flex justify-content-center align-items-center" style="background: #3B71CB;">
        <img src="assets/img/logomorowalilogin.png" alt="Logo" class="img-fluid w-60">
    </div>
    <div class="col-8 px-4 py-4 justify-content-center align-items-center">
        <div class="input-box text-center">
            <img src="assets/img/silacutbaru.png" alt="Logo Silacut" class="img-fluid w-60 mb-2">
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <p style="text-align: justify" class="fw-medium fs-4 mb-2">SILACUT adalah sebuah aplikasi berbasis website untuk melakukan pengajuan cuti untuk pegawai negeri sipil di lingkungan Pemerintahan Kabupaten Morowali</p>
                <div class="input-group mb-3">
                    <input type="text" placeholder="Username" class="form-control form-control-lg" id="username" autocomplete="on" name="username" value="<?php echo e(old('username')); ?>" oninput="hideError('username')">
                </div>
                <div class="input-group mb-4">
                    <input type="password" placeholder="Password" class="form-control form-control-lg" id="password" name="password" oninput="hideError('password')">
                </div>
                <div class="input-group mb-3">
                    <button type="submit" class="btn btn-lg btn-primary w-100" aria-label="Close">
                    <?php echo e(__('Login')); ?>

                    </button>
                </div>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="text-center text-secondary">BKPSDMD @ Kabupaten Morowali - 2022</div>
            </form>
        </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/auth/login.blade.php ENDPATH**/ ?>