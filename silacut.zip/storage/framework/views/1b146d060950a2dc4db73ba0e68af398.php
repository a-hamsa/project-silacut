<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section style="background-color: #5E72E4;" class="p-5">
  <div class="row">
    <div class="col-4 align-self-center">
      <div class="card info-card sales-card">

        <div class="card-body">
          <div class="row">
            <div class="col-9">
              <div class="row text-secondary">
                <h5 class="card-title">Jumlah Pegawai</h5>
              </div>
              <div class="row fw-bold">
                <h4><?php echo e($tb_pegawai); ?></h4>
              </div>
            </div>
            <div class="col-3">
            <div class="card-icon rounded-circle d-flex align-items-center justify-content-end">
              <i class="fa-solid fa-users fs-1 p-2"></i>
            </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <div class="col-4 align-self-center">
      <div class="card info-card sales-card">

        <div class="card-body">
          <div class="row">
            <div class="col-9">
              <div class="row text-secondary">
                <h5 class="card-title">Data Cuti</h5>
              </div>
              <div class="row fw-bold">
                <h4><?php echo e($tb_cuti); ?></h4>
              </div>
            </div>
            <div class="col-3">
            <div class="card-icon rounded-circle d-flex align-items-center justify-content-end">
              <i class="fa-solid fa-clipboard fs-1 p-2"></i>
            </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <div class="col-4 d-flex justify-content-end pr-5">
      <img src="<?php echo e(asset('assets/img/logomorowali.png')); ?>" style="width: 30%;">
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anastasia\Documents\Money Project\project-silacut\resources\views/layout/opd/dashboardopd.blade.php ENDPATH**/ ?>