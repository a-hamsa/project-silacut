<?php

namespace App\Http\Controllers\opd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Data_Cuti extends Controller
{
    //
}
